#include <iostream>

using namespace std;

int main()
{
    cout << "Sou calouro de BSI!!!!" << endl;
    return 0;
}
