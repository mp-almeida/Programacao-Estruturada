#include <iostream>

using namespace std;

int main()
{
    cout << "Meu nome �: Mariana Pires" << endl << endl;
    cout << "Sou do curso de Sistemas de Informa��o." << endl;
    cout << "Estou no primeiro ano." << endl;
    cout << "Gosto de programa��o!!!";



    return 0;
}
