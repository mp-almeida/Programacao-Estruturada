#include <iostream>

using namespace std;

int main()
{
    int num = 10;
    cout << "Numeros contidos entre 10 e 100: " << endl;
    while (num <= 100){
        cout << num << endl;
        num++;
    }
    return 0;
}
