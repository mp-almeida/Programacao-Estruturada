#include <iostream>

using namespace std;

int main()
{
    int num1, num2, soma;

    cout << "Digite um n�mero: " << endl;
    cin >> num1;
    cout << "Digite um n�mero: " << endl;
    cin >> num2;
    soma = num1 + num2;

    cout << "A soma dos dois n�meros � " << soma;
    return 0;
}
