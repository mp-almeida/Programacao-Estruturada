#include <iostream>

using namespace std;

int main()
{
    int dist, conv;

    cout << "Digite a dist�ncia em metros: " << endl;
    cin >> dist;
    conv = dist * 100;

    cout << "A dist�ncia " << dist << " em cent�metros � " << conv;
    return 0;
}
