#include <iostream>

using namespace std;

int main()
{
    float calculo;
    calculo = 2112 * 0.12;

    cout << "12% de 2112 � " << calculo << endl;
    return 0;
}
