#include <iostream>

using namespace std;

int main()
{
     int num;

    cout << "Digite um n�mero qualquer: " << endl;
    cin >> num;

    cout << "O n�mero informado foi " << num;
    return 0;
}
