#include <iostream>

using namespace std;

int main()
{
    cout << "Sou aluno de BSI no IFSP" << endl;
    return 0;
}
