#include <iostream>

using namespace std;

int main()
{
    cout << "----------Hoje � um dia muito feliz...----------" << endl;
    cout << "---------------Tenho prova de PES---------------" << endl;
    cout << "-----------------Vou tirar DEZ.-----------------" << endl;
    return 0;
}
