#include <iostream>

using namespace std;

int main()
{
    cout << "PES - Programa��o Estruturada - Turma A" << endl << endl;
    cout << "Prova Bimestral." << endl << endl;
    cout << "Valor - 4.0 pontos" << endl << endl;
    cout << "Aluno: Mariana Pires Almeida" << endl;
    cout << "Matricula: vp3033023" << endl << endl;
    return 0;
}
