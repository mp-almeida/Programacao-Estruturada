#include <iostream>

using namespace std;

int main()
{
    int i = 50;

    cout << "Veja o contador em ordem crescente" << endl;

    while (i >= 1){
        cout << i << endl;
        i = i - 1;
    }
    return 0;
}
