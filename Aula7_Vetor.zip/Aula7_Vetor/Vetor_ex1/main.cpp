#include <iostream>

using namespace std;

int main()
{
    int vetor[5], i;

    for(i = 0; i <5; i++){
        cout << "Digite um numero para armazenar na posicao: " << i << " do vetor." << endl;
        cin >> vetor[1];
    }

    return 0;
}
